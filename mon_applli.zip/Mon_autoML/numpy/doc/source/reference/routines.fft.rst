.. _routines.fft:
.. automodule:: numpy.fft
