distutils.misc_util
===================

.. automodule:: numpy.distutils.misc_util
   :members:
   :undoc-members:
   :exclude-members: Configuration
